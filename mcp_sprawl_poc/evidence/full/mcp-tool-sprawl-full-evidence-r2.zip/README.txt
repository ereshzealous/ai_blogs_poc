MCP Tool Sprawl POC: the complete recorded-run evidence (evidence revision r2)

This archive lives at evidence/full/mcp-tool-sprawl-full-evidence-r2.zip in https://github.com/ereshzealous/ai_blogs_poc/tree/main/mcp_sprawl_poc. Unzip it at the root of that folder to
place every file at the path the repository's evidence and the Lab Console name.

  experiment/raw/blind-rerun-2026-10-01/      the published run: every row's messages, raw model calls, tool calls, gateway traces,
                                            approvals and effects ledger (rows/), hash-chained audit (audit/), run-meta.json
  experiment/raw/blind-main/                  the first live pass, the noise floor, with the same detail
  experiment/raw/blind-repeat/                the first pass's preregistered repeat pass
  experiment/recorded-run/                    every replay without the model, row by row
  experiment/analysis/                        the analysis of both live passes
  evidence/runs/                              the proof packs of both passes (SHA256SUMS hash the development bytes)
  evidence/negative-control/, evidence/verification/   the first pass's negative control and run comparison

PUBLIC-SHA256SUMS hashes every file as published here. Absolute local paths in recorded files were replaced with the
same paths relative to the repository root; public-redactions.json lists each file, the field, the hash of the original
bytes and of the published bytes. No measured value changed.
